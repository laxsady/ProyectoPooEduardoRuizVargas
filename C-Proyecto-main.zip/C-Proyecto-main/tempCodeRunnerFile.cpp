#include <iostream>
#include <vector>
#include "Situacion_problema_Poo.h"

char option;
                    cout << "Módulo salarios:\n"
                    << "1) Mostrar salario actual\n"
                    << "2) Agregar bono\n"
                    << "3) Deducir salario\n"
                    << "Seleccione una opción: ";
                    cin >> option;